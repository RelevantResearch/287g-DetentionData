import { State, County, Status, Agency, ApiFilters } from '../types';

const API_BASE_URL = import.meta.env.VITE_REACT_APP_API_URL || 'http://localhost:5000';

// Dummy data
const DUMMY_STATES: State[] = [
  { id: 1, name: 'California', code: 'CA' },
  { id: 2, name: 'Texas', code: 'TX' },
  { id: 3, name: 'Florida', code: 'FL' },
  { id: 4, name: 'New York', code: 'NY' },
  { id: 5, name: 'Arizona', code: 'AZ' },
  { id: 6, name: 'Georgia', code: 'GA' },
  { id: 7, name: 'North Carolina', code: 'NC' },
  { id: 8, name: 'Virginia', code: 'VA' }
];

const DUMMY_COUNTIES: County[] = [
  // California counties
  { id: 1, name: 'Los Angeles County', state_id: 1, state_name: 'California' },
  { id: 2, name: 'Orange County', state_id: 1, state_name: 'California' },
  { id: 3, name: 'San Diego County', state_id: 1, state_name: 'California' },
  { id: 4, name: 'Riverside County', state_id: 1, state_name: 'California' },
  
  // Texas counties
  { id: 5, name: 'Harris County', state_id: 2, state_name: 'Texas' },
  { id: 6, name: 'Dallas County', state_id: 2, state_name: 'Texas' },
  { id: 7, name: 'Tarrant County', state_id: 2, state_name: 'Texas' },
  { id: 8, name: 'Bexar County', state_id: 2, state_name: 'Texas' },
  
  // Florida counties
  { id: 9, name: 'Miami-Dade County', state_id: 3, state_name: 'Florida' },
  { id: 10, name: 'Broward County', state_id: 3, state_name: 'Florida' },
  { id: 11, name: 'Palm Beach County', state_id: 3, state_name: 'Florida' },
  { id: 12, name: 'Hillsborough County', state_id: 3, state_name: 'Florida' },
  
  // New York counties
  { id: 13, name: 'New York County', state_id: 4, state_name: 'New York' },
  { id: 14, name: 'Kings County', state_id: 4, state_name: 'New York' },
  { id: 15, name: 'Queens County', state_id: 4, state_name: 'New York' },
  { id: 16, name: 'Nassau County', state_id: 4, state_name: 'New York' },
  
  // Arizona counties
  { id: 17, name: 'Maricopa County', state_id: 5, state_name: 'Arizona' },
  { id: 18, name: 'Pima County', state_id: 5, state_name: 'Arizona' },
  
  // Georgia counties
  { id: 19, name: 'Fulton County', state_id: 6, state_name: 'Georgia' },
  { id: 20, name: 'Gwinnett County', state_id: 6, state_name: 'Georgia' },
  
  // North Carolina counties
  { id: 21, name: 'Mecklenburg County', state_id: 7, state_name: 'North Carolina' },
  { id: 22, name: 'Wake County', state_id: 7, state_name: 'North Carolina' },
  
  // Virginia counties
  { id: 23, name: 'Fairfax County', state_id: 8, state_name: 'Virginia' },
  { id: 24, name: 'Virginia Beach City', state_id: 8, state_name: 'Virginia' }
];

const DUMMY_STATUSES: Status[] = [
  { id: 1, name: 'Active', description: 'Currently participating in 287(g) program' },
  { id: 2, name: 'Inactive', description: 'No longer participating in 287(g) program' },
  { id: 3, name: 'Pending', description: 'Application or renewal in progress' },
  { id: 4, name: 'Suspended', description: 'Temporarily suspended from program' },
  { id: 5, name: 'Terminated', description: 'Agreement terminated' }
];

const DUMMY_AGENCIES: Agency[] = [
  {
    id: 1,
    name: 'Los Angeles County Sheriff\'s Department',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2019-03-15',
    last_seen: '2024-01-15',
    status: 'Active',
    county: 'Los Angeles County',
    state: 'California',
    extracted_link: 'https://lasd.org',
    county_id: 1,
    state_id: 1,
    status_id: 1
  },
  {
    id: 2,
    name: 'Orange County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Task Force',
    signed: '2018-07-22',
    last_seen: '2024-01-10',
    status: 'Active',
    county: 'Orange County',
    state: 'California',
    extracted_link: 'https://ocsheriff.gov',
    county_id: 2,
    state_id: 1,
    status_id: 1
  },
  {
    id: 3,
    name: 'Harris County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2020-01-10',
    last_seen: '2023-12-20',
    status: 'Inactive',
    county: 'Harris County',
    state: 'Texas',
    extracted_link: 'https://hcso.org',
    county_id: 5,
    state_id: 2,
    status_id: 2
  },
  {
    id: 4,
    name: 'Dallas Police Department',
    type: 'Police',
    support_type: 'Task Force',
    signed: '2019-11-05',
    last_seen: '2024-01-08',
    status: 'Active',
    county: 'Dallas County',
    state: 'Texas',
    extracted_link: 'https://dallaspolice.net',
    county_id: 6,
    state_id: 2,
    status_id: 1
  },
  {
    id: 5,
    name: 'Miami-Dade Police Department',
    type: 'Police',
    support_type: 'Jail Enforcement',
    signed: '2017-09-12',
    last_seen: '2024-01-12',
    status: 'Active',
    county: 'Miami-Dade County',
    state: 'Florida',
    extracted_link: 'https://mdpd.com',
    county_id: 9,
    state_id: 3,
    status_id: 1
  },
  {
    id: 6,
    name: 'Broward Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Task Force',
    signed: '2018-04-18',
    last_seen: '2023-11-30',
    status: 'Suspended',
    county: 'Broward County',
    state: 'Florida',
    extracted_link: 'https://sheriff.org',
    county_id: 10,
    state_id: 3,
    status_id: 4
  },
  {
    id: 7,
    name: 'NYPD Immigration Task Force',
    type: 'Police',
    support_type: 'Task Force',
    signed: '2016-12-01',
    last_seen: '2023-08-15',
    status: 'Terminated',
    county: 'New York County',
    state: 'New York',
    extracted_link: 'https://nyc.gov/nypd',
    county_id: 13,
    state_id: 4,
    status_id: 5
  },
  {
    id: 8,
    name: 'Maricopa County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2019-06-30',
    last_seen: '2024-01-14',
    status: 'Active',
    county: 'Maricopa County',
    state: 'Arizona',
    extracted_link: 'https://mcso.org',
    county_id: 17,
    state_id: 5,
    status_id: 1
  },
  {
    id: 9,
    name: 'Fulton County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2020-08-14',
    last_seen: '2024-01-05',
    status: 'Pending',
    county: 'Fulton County',
    state: 'Georgia',
    extracted_link: 'https://fultonsheriff.org',
    county_id: 19,
    state_id: 6,
    status_id: 3
  },
  {
    id: 10,
    name: 'Mecklenburg County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Task Force',
    signed: '2018-02-28',
    last_seen: '2024-01-11',
    status: 'Active',
    county: 'Mecklenburg County',
    state: 'North Carolina',
    extracted_link: 'https://mecksheriff.com',
    county_id: 21,
    state_id: 7,
    status_id: 1
  },
  {
    id: 11,
    name: 'Fairfax County Police Department',
    type: 'Police',
    support_type: 'Task Force',
    signed: '2019-10-20',
    last_seen: '2024-01-13',
    status: 'Active',
    county: 'Fairfax County',
    state: 'Virginia',
    extracted_link: 'https://fairfaxcounty.gov/police',
    county_id: 23,
    state_id: 8,
    status_id: 1
  },
  {
    id: 12,
    name: 'San Diego County Sheriff\'s Department',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2017-05-15',
    last_seen: '2023-10-22',
    status: 'Inactive',
    county: 'San Diego County',
    state: 'California',
    extracted_link: 'https://sdsheriff.gov',
    county_id: 3,
    state_id: 1,
    status_id: 2
  },
  {
    id: 13,
    name: 'Tarrant County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2020-03-08',
    last_seen: '2024-01-09',
    status: 'Active',
    county: 'Tarrant County',
    state: 'Texas',
    extracted_link: 'https://tarrantcounty.com/sheriff',
    county_id: 7,
    state_id: 2,
    status_id: 1
  },
  {
    id: 14,
    name: 'Palm Beach County Sheriff\'s Office',
    type: 'Sheriff',
    support_type: 'Task Force',
    signed: '2018-11-12',
    last_seen: '2024-01-07',
    status: 'Active',
    county: 'Palm Beach County',
    state: 'Florida',
    extracted_link: 'https://pbso.org',
    county_id: 11,
    state_id: 3,
    status_id: 1
  },
  {
    id: 15,
    name: 'Pima County Sheriff\'s Department',
    type: 'Sheriff',
    support_type: 'Jail Enforcement',
    signed: '2019-01-25',
    last_seen: '2023-12-18',
    status: 'Pending',
    county: 'Pima County',
    state: 'Arizona',
    extracted_link: 'https://pimasheriff.org',
    county_id: 18,
    state_id: 5,
    status_id: 3
  }
];

class ApiError extends Error {
  status: number;
  
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.name = 'ApiError';
  }
}

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const apiService = {
  async getStates(): Promise<State[]> {
    try {
      await delay(500); // Simulate network delay
      return DUMMY_STATES;
    } catch (error) {
      console.error('Error fetching states:', error);
      throw error;
    }
  },

  async getCounties(stateId?: number): Promise<County[]> {
    try {
      await delay(300); // Simulate network delay
      if (stateId) {
        return DUMMY_COUNTIES.filter(county => county.state_id === stateId);
      }
      return DUMMY_COUNTIES;
    } catch (error) {
      console.error('Error fetching counties:', error);
      throw error;
    }
  },

  async getStatus(): Promise<Status[]> {
    try {
      await delay(200); // Simulate network delay
      return DUMMY_STATUSES;
    } catch (error) {
      console.error('Error fetching status:', error);
      throw error;
    }
  },

  async getAgencies(filters?: ApiFilters): Promise<Agency[]> {
    try {
      await delay(400); // Simulate network delay
      let filteredAgencies = DUMMY_AGENCIES;
      
      if (filters?.state_id) {
        filteredAgencies = filteredAgencies.filter(agency => agency.state_id === filters.state_id);
      }
      if (filters?.county_id) {
        filteredAgencies = filteredAgencies.filter(agency => agency.county_id === filters.county_id);
      }
      if (filters?.status_id) {
        filteredAgencies = filteredAgencies.filter(agency => agency.status_id === filters.status_id);
      }

      return filteredAgencies;
    } catch (error) {
      console.error('Error fetching agencies:', error);
      throw error;
    }
  }
};