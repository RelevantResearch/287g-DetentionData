export interface State {
  id: number;
  name: string;
  code?: string;
}

export interface County {
  id: number;
  name: string;
  state_id: number;
  state_name?: string;
}

export interface Status {
  id: number;
  name: string;
  description?: string;
}

export interface Agency {
  id: number;
  name: string;
  type: string;
  support_type: string;
  signed: string;
  last_seen: string;
  status: string;
  county: string;
  state: string;
  extracted_link: string;
  county_id?: number;
  state_id?: number;
  status_id?: number;
}

export interface ApiFilters {
  state_id?: number;
  county_id?: number;
  status_id?: number;
}